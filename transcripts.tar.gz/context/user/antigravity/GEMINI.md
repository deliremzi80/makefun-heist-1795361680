# Antigravity Instructions
Follow best practices for software engineering, web development, and 3D graphics.
